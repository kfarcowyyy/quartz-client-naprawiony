#!/usr/bin/env node
/* Incremental Quartz Client update: English default + Polish/English selector. */
const fs = require('node:fs');
const path = require('node:path');

const root = process.cwd();
const updates = [
  {
    file: 'src/store.js',
    find: "  voicechat: true,\n  javaPath: '',",
    replace: "  voicechat: true,\n  javaPath: '',\n  language: 'en',",
  },
  {
    file: 'src/extras.js',
    find: "const paths = require('./paths');",
    replace: "const paths = require('./paths');\nconst quartzMod = require('./quartz-mod');",
  },
  {
    file: 'src/extras.js',
    find: "async function ensureVoiceChat(inst, log) {\n  if (!isModded(inst)) return;",
    replace: "async function ensureQuartzMod(inst, log) {\n  await quartzMod.ensure(inst, log);\n}\n\nasync function ensureVoiceChat(inst, log) {\n  if (!isModded(inst)) return;\n  await ensureQuartzMod(inst, log);",
  },
  {
    file: 'src/extras.js',
    find: "  if (!isModded(inst)) return;\n  await tryInstall('fabric-api', inst, log);\n  if (voicechat)",
    replace: "  if (!isModded(inst)) return;\n  await ensureQuartzMod(inst, log);\n  await tryInstall('fabric-api', inst, log);\n  if (voicechat)",
  },
  {
    file: 'src/extras.js',
    find: 'module.exports = { ensureVoiceChat, applyDefaults };',
    replace: 'module.exports = { ensureQuartzMod, ensureVoiceChat, applyDefaults };',
  },
  {
    file: 'src/main.js',
    find: "  if (settings.voicechat) {\n    send('status', 'Sprawdzam Simple Voice Chat...');",
    replace: "  send('status', 'Sprawdzam Quartz Client mod...');\n  await extras.ensureQuartzMod(inst, (m) => send('log', m));\n\n  if (settings.voicechat) {\n    send('status', 'Sprawdzam Simple Voice Chat...');",
  },
  {
    file: 'renderer/index.html',
    find: '<html lang="pl">',
    replace: '<html lang="en">',
  },
  {
    file: 'renderer/index.html',
    find: '<div class="brand-sub">Client</div>',
    replace: '<div class="brand-sub">High Performance Minecraft Client</div>',
  },
  {
    file: 'renderer/index.html',
    find: `    <div class="brand">\n      <svg width="38" height="38" viewBox="0 0 48 48" aria-hidden="true">\n        <defs>\n          <linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">\n            <stop offset="0" stop-color="#f4a6c8" />\n            <stop offset="1" stop-color="#9a7cf2" />\n          </linearGradient>\n        </defs>\n        <polygon points="24,3 42,13 42,35 24,45 6,35 6,13" fill="url(#g1)" />\n        <polygon points="24,3 42,13 24,24 6,13" fill="#fff" opacity=".45" />\n        <polygon points="24,24 42,13 42,35 24,45" fill="#6c4fd6" opacity=".28" />\n        <polygon points="24,24 6,13 6,35 24,45" fill="#fff" opacity=".12" />\n      </svg>\n      <div>`,
    replace: '    <div class="brand">\n      <img class="brand-icon" src="quartz-icon.png" alt="Quartz Client" />\n      <div>',
  },
  {
    file: 'renderer/style.css',
    find: '.brand { display: flex; align-items: center; gap: 12px; padding: 0 6px; }',
    replace: '.brand { display: flex; align-items: center; gap: 12px; padding: 0 6px; }\n.brand-icon { width: 38px; height: 38px; object-fit: contain; flex: none; }',
  },
  {
    file: 'src/main.js',
    find: "    title: 'Quartz Client',\n    autoHideMenuBar: true,",
    replace: "    title: 'Quartz Client',\n    icon: path.join(__dirname, '..', 'renderer', 'quartz-icon.png'),\n    autoHideMenuBar: true,",
  },
  {
    file: 'package.json',
    find: '  "version": "0.1.0",',
    replace: '  "version": "0.2.1",',
  },
  {
    file: 'package.json',
    find: '    "win": {\n      "target": [',
    replace: '    "win": {\n      "icon": "build/quartz-client.ico",\n      "target": [',
  },
  {
    file: 'renderer/index.html',
    find: '  <script src="app.js"></script>',
    replace: '  <script src="i18n.js"></script>\n  <script src="app.js"></script>',
  },
  {
    file: 'renderer/app.js',
    find: '<p class="sub">Zapisują się automatycznie.</p>',
    replace: '<p class="sub">Zapisują się automatycznie.</p>\n    <section class="card"><label class="field">Język / Language<select id="s-lang"><option value="en">English</option><option value="pl">Polski</option></select></label></section>',
  },
  {
    file: 'renderer/app.js',
    find: "  $('#s-java').addEventListener('change', (e) => save({ javaPath: e.target.value.trim() }));",
    replace: "  $('#s-java').addEventListener('change', (e) => save({ javaPath: e.target.value.trim() }));\n  $('#s-lang').value = state.settings.language || 'en';\n  $('#s-lang').addEventListener('change', async (e) => {\n    await save({ language: e.target.value });\n    quartzI18n.setLanguage(e.target.value);\n    renderNav();\n    render();\n  });",
  },
  {
    file: 'renderer/app.js',
    find: "    try { state.account = await api('auth:microsoft'); toast('Zalogowano'); }\n    catch (err) { toast(err.message, true); }",
    replace: "    try { state.account = await api('auth:microsoft'); toast('Zalogowano'); }\n    catch (err) { if (!/error\\.gui\\.close/i.test(err.message)) toast(err.message, true); }",
  },
  {
    file: 'renderer/app.js',
    find: '    await refreshInstances();\n    api(\'versions:list\')',
    replace: "    quartzI18n.setLanguage(state.settings.language || 'en');\n    await refreshInstances();\n    api('versions:list')",
  },
  {
    file: 'renderer/style.css',
    find: '.brand-sub { font-size: 12px; color: var(--muted); letter-spacing: 3px; text-transform: uppercase; margin-top: 3px; }',
    replace: '.brand-sub { font-size: 9px; color: var(--muted); letter-spacing: .45px; text-transform: none; margin-top: 4px; white-space: nowrap; }',
  },
  {
    file: '.github/workflows/build.yml',
    find: '      - name: Install dependencies\n        run: npm install',
    replace: '      - uses: actions/setup-java@v4\n        with:\n          distribution: temurin\n          java-version: "21"\n\n      - uses: gradle/actions/setup-gradle@v4\n        with:\n          gradle-version: "9.8.2"\n\n      - name: Build Quartz in-game mod\n        run: gradle -p quartz-mod build\n\n      - name: Install dependencies\n        run: npm install',
  },
  {
    file: '.github/workflows/build.yml',
    find: '      - name: Build .exe\n        run: npm run dist',
    replace: '      - name: Build .exe\n        run: npm run dist\n\n      - name: Add Quartz in-game mod to artifacts\n        shell: pwsh\n        run: |\n          $mod = Get-ChildItem quartz-mod/build/libs/quartz-client-mod-*.jar | Where-Object { $_.Name -notmatch "sources|dev" } | Select-Object -First 1\n          if (-not $mod) { throw "Quartz mod JAR was not produced" }\n          Copy-Item $mod.FullName dist/Quartz-Client-Mod-1.21.11.jar',
  },
  {
    file: '.github/workflows/build.yml',
    find: '          path: dist/*.exe',
    replace: '          path: dist/*',
  },
  {
    file: '.github/workflows/build.yml',
    find: '          files: dist/*.exe',
    replace: '          files: dist/*',
  },
];

function read(rel) {
  const file = path.join(root, rel);
  if (!fs.existsSync(file)) throw new Error(`Missing expected file: ${rel}`);
  return fs.readFileSync(file, 'utf8');
}

const changed = new Map();
for (const edit of updates) {
  let content = changed.has(edit.file) ? changed.get(edit.file) : read(edit.file);
  const count = content.split(edit.find).length - 1;
  if (count === 0 && content.includes(edit.replace)) continue;
  if (count !== 1) throw new Error(`${edit.file}: expected one match for update anchor, found ${count}`);
  changed.set(edit.file, content.replace(edit.find, edit.replace));
}
changed.set('renderer/i18n.js', fs.readFileSync(path.join(__dirname, 'i18n.js'), 'utf8'));
changed.set('src/quartz-mod.js', fs.readFileSync(path.join(__dirname, 'src-quartz-mod.js'), 'utf8'));
changed.set('renderer/quartz-icon.png', fs.readFileSync(path.join(__dirname, 'quartz-icon.png')));
changed.set('build/quartz-client.ico', fs.readFileSync(path.join(__dirname, 'build', 'quartz-client.ico')));

for (const [rel, content] of changed) {
  const target = path.join(root, rel);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  const temp = `${target}.quartz-update-tmp`;
  fs.writeFileSync(temp, content, 'utf8');
  fs.renameSync(temp, target);
}
console.log(`Applied Quartz language update to ${changed.size} files.`);
