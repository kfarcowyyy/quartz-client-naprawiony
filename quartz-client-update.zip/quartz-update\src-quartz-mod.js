const fs = require('fs');
const path = require('path');
const { download } = require('./net');
const paths = require('./paths');
const store = require('./store');

const SUPPORTED_VERSION = '1.21.11';
const ASSET_URL = 'https://github.com/kfarcowyyy/quartz-client-naprawiony/releases/latest/download/Quartz-Client-Mod-1.21.11.jar';
const pending = new Map();

async function ensure(inst, log) {
  if (!['fabric', 'quilt'].includes(inst.loader)) return;
  if (inst.mcVersion !== SUPPORTED_VERSION) {
    log && log(`[Quartz] In-game mod is not built for Minecraft ${inst.mcVersion} yet; skipping.`);
    return;
  }
  if (pending.has(inst.id)) return pending.get(inst.id);
  const job = (async () => {
    const dir = path.join(paths.instDir(inst.id), 'mods');
    const target = path.join(dir, 'quartz-client-mod-1.21.11.jar');
    const temp = target + '.download';
    fs.mkdirSync(dir, { recursive: true });
    const configPath = path.join(paths.instDir(inst.id), 'config', 'quartz-client.json');
    let modConfig = {};
    try { modConfig = JSON.parse(fs.readFileSync(configPath, 'utf8')); } catch { }
    modConfig.language = store.get().language === 'pl' ? 'pl' : 'en';
    fs.mkdirSync(path.dirname(configPath), { recursive: true });
    fs.writeFileSync(configPath, JSON.stringify(modConfig, null, 2));
    try {
      await download(ASSET_URL, temp);
      const next = fs.readFileSync(temp);
      if (fs.existsSync(target) && fs.readFileSync(target).equals(next)) {
        fs.rmSync(temp, { force: true });
        return;
      }
      fs.rmSync(target, { force: true });
      fs.renameSync(temp, target);
      log && log('[Quartz] In-game mod installed/updated.');
    } catch (e) {
      fs.rmSync(temp, { force: true });
      log && log(`[Quartz] Could not update in-game mod: ${e.message}`);
    }
  })();
  pending.set(inst.id, job);
  try { await job; } finally { pending.delete(inst.id); }
}

module.exports = { ensure };
