# Quartz Client incremental update

This ZIP adds an incremental update to the current Electron launcher and a separate Fabric mod project. It does not replace or repackage the repository.

## Apply in GitHub Codespaces

Upload the ZIP to the repository root, then run:

```bash
unzip -o quartz-client-update.zip -d .
node quartz-update/apply-update.cjs
git status --short
git add package.json src/store.js src/main.js src/extras.js src/quartz-mod.js renderer/index.html renderer/app.js renderer/style.css renderer/i18n.js renderer/quartz-icon.png build/quartz-client.ico .github/workflows/build.yml quartz-mod
git commit -m "Add Quartz in-game HUD and menu"
git push origin main
git tag v0.2.1
git push origin v0.2.1
```

The version tag runs the Windows installer workflow and builds the in-game mod JAR. The Release contains the installer, portable app, and `Quartz-Client-Mod-1.21.11.jar`. The launcher downloads that JAR automatically for new and existing Fabric/Quilt 1.21.11 instances.

The update script checks every expected source anchor before writing. If the repository has changed and an anchor no longer matches exactly once, it stops without applying changes.

## Included in this first mod build

- Right Shift opens the Quartz menu; the binding can be changed in Minecraft Controls.
- In-game mod list with restart-required enable/disable.
- FPS/CPS HUD with a draggable position, editable text template, background/text color options, and English/Polish labels.
- Screenshot list reads the instance `screenshots` folder; F2 remains Minecraft's screenshot key.
- English default launcher UI and an English/Polish selector in Settings.
- Quartz logo asset, transparent outside the logo, for the launcher window and Windows installer.

## Compatibility and services

The included mod build targets Minecraft 1.21.11 with Fabric/Quilt. It is not a universal JAR. Vanilla cannot load mods, and this launcher currently does not implement Forge/NeoForge. Other Minecraft releases need matching builds and compatibility checks; this ZIP does not claim those combinations work. Free capes and skins visible to other Quartz users need a shared cosmetics service, which is not present or deployed in the repository.
