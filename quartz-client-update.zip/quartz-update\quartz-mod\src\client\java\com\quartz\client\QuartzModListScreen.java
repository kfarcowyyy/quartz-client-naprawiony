package com.quartz.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class QuartzModListScreen extends Screen {
    private final Screen parent;
    private final List<Path> mods = new ArrayList<>();
    public QuartzModListScreen(Screen parent) { super(QuartzText.of("Installed mods", "Zainstalowane mody")); this.parent = parent; }

    @Override
    protected void init() {
        mods.clear();
        Path folder = Minecraft.getInstance().gameDirectory.toPath().resolve("mods");
        try {
            Files.createDirectories(folder);
            try (var stream = Files.list(folder)) {
                stream.filter(p -> p.getFileName().toString().endsWith(".jar") || p.getFileName().toString().endsWith(".jar.disabled"))
                        .sorted().forEach(mods::add);
            }
        } catch (Exception ignored) { }
        int maxRows = Math.max(1, (height - 100) / 28);
        for (int i = 0; i < Math.min(mods.size(), maxRows); i++) {
            Path file = mods.get(i);
            String name = file.getFileName().toString();
            boolean enabled = name.endsWith(".jar");
            String label = (enabled ? "✓  " : "○  ") + name.replace(".jar.disabled", "").replace(".jar", "");
            addRenderableWidget(Button.builder(Component.literal(label), b -> {
                try {
                    Path next = enabled ? file.resolveSibling(name + ".disabled") : file.resolveSibling(name.substring(0, name.length() - ".disabled".length()));
                    Files.move(file, next);
                    Minecraft.getInstance().setScreen(new QuartzModListScreen(parent));
                } catch (Exception ignored) { }
            }).bounds(width / 2 - 170, 42 + i * 28, 340, 24).build());
        }
        addRenderableWidget(Button.builder(QuartzText.of("Done", "Gotowe"), b -> onClose())
                .bounds(width / 2 - 60, height - 36, 120, 24).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        graphics.drawCenteredString(font, title, width / 2, 18, 0xFFFFFFFF);
        graphics.drawCenteredString(font, QuartzText.of("Changes take effect after restarting the game", "Zmiany zadziałają po ponownym uruchomieniu gry"), width / 2, height - 58, 0xFFB8C7F2);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public void onClose() { Minecraft.getInstance().setScreen(parent); }
}
